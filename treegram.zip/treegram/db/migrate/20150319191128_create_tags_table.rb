class CreateTagsTable < ActiveRecord::Migration

end
