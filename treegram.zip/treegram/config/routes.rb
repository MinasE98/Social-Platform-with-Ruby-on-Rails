 Rails.application.routes.draw do
  get '/users/search', to: 'users#search', as: "search_user"
  get '/' => 'home#index'
  resources :users do
    resources :photos
  end
  resources :photos do
    resources :comments
  end
  resources :tags, only: [:create, :destroy]
  get '/log-in' => "sessions#new"
  post '/log-in' => "sessions#create"
  get '/log-out' => "sessions#destroy", as: :log_out
  post 'users/:id/follow', to: 'users#follow', as: "follow_user"
  delete 'users/:id/unfollow', to: 'users#unfollow', as: "unfollow_user"
  delete 'users/:user_id/photos/:id', to: 'photos#destroy', as: "users_photos_destroy"  
end