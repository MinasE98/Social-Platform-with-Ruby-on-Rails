class CommentsController < ApplicationController
	def index
	  @comments = Comment.all
	end
  
  def create
    @photo = Photo.find(params[:photo_id])
    @comment = @photo.comments.create(params[:comment].permit(:content, :photo_id, :user_id))
    redirect_to :back
  end

  def destroy
    @comment.destroy
  end
  
  def comment_params
  	params.require(:comment).permit(:content, :photo_id, :user_id)
	end
end
