class UsersController < ApplicationController
  include UserHelper
  def index
    @users = User.all.where("id != ?", current_user.id)
  end

  def create
    @user = User.new(user_params)
    @user.valid?
    if !@user.is_email?
      flash[:alert] = "Input a properly formatted email."
      redirect_to :back
    elsif @user.errors.messages[:email] != nil
      flash[:notice]= "That email " + @user.errors.messages[:email].first
      redirect_to :back
    elsif @user.save
      flash[:notice]= "Signup successful. Welcome to the site!"
      session[:user_id] = @user.id
      redirect_to user_path(@user)
    else
      flash[:alert] = "There was a problem creating your account. Please try again."
      redirect_to :back
    end
  end

  def new
  end

  def show
    @users = User.all
    @user = User.find(params[:id])
    @tag = Tag.new
  end

  def showafter(results)
    @user = User.find(params[:search])
  end

  def search
    if params[:search].present?
      @parameter = params[:search]
      @results = User.all.where("id LIKE :search", search: "%#{@parameter}%")
      redirect_to showafter(@results)
    end
  end

  def follow
    @user = User.find(params[:id])
    current_user.followees << @user
    redirect_to :back
  end

  def unfollow
    @user = User.find(params[:id])
    current_user.followed_users.find_by(followee_id: @user.id).destroy
    redirect_to :back
  end


  def user_params
    params.require(:user).permit(:email, :password, :password_confirmation, :avatar)
  end
    
end
