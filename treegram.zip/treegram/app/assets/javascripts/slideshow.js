$(document).ready(function() {
  var currentImageIndex = 0;
  var images = $('.slideshow-image');
  var timeout;

  function updateSlideshow(userId, images) {
    $('.title').text(images[currentImageIndex].title);
    $(images[currentImageIndex]).css('display', 'none');
    currentImageIndex = (currentImageIndex + 1) % images.length;
    $(images[currentImageIndex]).css('display', 'inline');
    timeout = setTimeout(function() {
      updateSlideshow(userId, images);
    }, 1000);
    $(images[currentImageIndex]).css('opacity', '1');
  }

  $('.slideshow').on('mouseenter', function() {
    var userId = $(this).data('user_id');
    var images = $(this).find('.slideshow-image');
    updateSlideshow(userId, images);
  });

  $('.slideshow').on('mouseleave', function() {
    clearTimeout(timeout);
  });

  $('.slideshow-image').on('click', function() {
    // Pause the slideshow
    clearTimeout(timeout);

    // Retrieve the ID of the clicked image
    var imageId = $(this).data('image_id');

    // Send an HTTP request to the server to retrieve the latest comments for the image
    $.ajax({
      url: '/comments?image_id=' + imageId,
      type: 'GET',
      success: function(response) {
        // Display the comments in a popup window
        $('#comments-popup').html(response).dialog({
          // Add a textbox and buttons for the user to enter and submit a comment or close the window
          buttons: [
            {
              text: 'Submit Comment',
              click: function() {
                // Send an HTTP request to the server to submit the comment
                $.ajax({
                  url: '/comments',
                  type: 'POST',
                  data: {
                    image_id: imageId,
                    text: $('#comment-text').val()
                  },
                  success: function() {
                    // Refresh the comments in the popup window
                    $.ajax({
                      url: '/comments?image_id=' + imageId,
                      type: 'GET',
                      success: function(response) {
                        $('#comments-popup').html(response);
                      }
                    });
                  }
                });
              }
            },
            {
              text: 'Close',
              click: function() {
                $(this).dialog('close');
              }
            }
          ]
        });
      }
    });
  });
});
